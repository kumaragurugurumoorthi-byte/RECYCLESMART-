import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import ws from "ws";
import { 
  users, 
  recyclingItems, 
  rewards, 
  redemptions,
  type User, 
  type UpsertUser,
  type RecyclingItem,
  type InsertRecyclingItem,
  type Reward,
  type InsertReward,
  type Redemption,
  type InsertRedemption
} from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL! });
const db = drizzle({ client: pool });

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserPoints(userId: string, pointsDelta: number, weightKg?: number): Promise<User>;
  
  // Recycling Items
  getRecyclingHistory(userId: string, limit?: number): Promise<RecyclingItem[]>;
  createRecyclingItem(item: InsertRecyclingItem): Promise<RecyclingItem>;
  
  // Rewards
  getAllRewards(): Promise<Reward[]>;
  getReward(id: number): Promise<Reward | undefined>;
  
  // Redemptions
  createRedemption(redemption: InsertRedemption): Promise<Redemption>;
  getUserRedemptions(userId: string): Promise<Redemption[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: userData.email,
          firstName: userData.firstName,
          lastName: userData.lastName,
          profileImageUrl: userData.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserPoints(userId: string, pointsDelta: number, weightKg: number = 0): Promise<User> {
    const carbonSavedDelta = Math.floor(weightKg * 0.5);
    
    const [user] = await db.update(users)
      .set({
        totalPoints: sql`${users.totalPoints} + ${pointsDelta}`,
        totalRecycled: sql`${users.totalRecycled} + ${weightKg}`,
        carbonSaved: sql`${users.carbonSaved} + ${carbonSavedDelta}`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    
    return user;
  }

  async getRecyclingHistory(userId: string, limit: number = 50): Promise<RecyclingItem[]> {
    return await db.select()
      .from(recyclingItems)
      .where(eq(recyclingItems.userId, userId))
      .orderBy(desc(recyclingItems.scannedAt))
      .limit(limit);
  }

  async createRecyclingItem(item: InsertRecyclingItem): Promise<RecyclingItem> {
    const [result] = await db.insert(recyclingItems).values(item).returning();
    return result;
  }

  async getAllRewards(): Promise<Reward[]> {
    return await db.select().from(rewards).where(eq(rewards.isActive, true));
  }

  async getReward(id: number): Promise<Reward | undefined> {
    const [result] = await db.select().from(rewards).where(eq(rewards.id, id));
    return result;
  }

  async createRedemption(redemption: InsertRedemption): Promise<Redemption> {
    const [result] = await db.insert(redemptions).values(redemption).returning();
    return result;
  }

  async getUserRedemptions(userId: string): Promise<Redemption[]> {
    return await db.select()
      .from(redemptions)
      .where(eq(redemptions.userId, userId))
      .orderBy(desc(redemptions.redeemedAt));
  }
}

export const storage = new DatabaseStorage();
