import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertRecyclingItemSchema,
  insertRedemptionSchema 
} from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Setup Replit Auth
  await setupAuth(app);
  
  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Recycling items routes
  app.get("/api/recycling-history", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const items = await storage.getRecyclingHistory(userId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching recycling history:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/recycling-items", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertRecyclingItemSchema.parse({
        ...req.body,
        userId,
      });
      
      // Create the recycling item
      const item = await storage.createRecyclingItem(validatedData);
      
      // Update user points
      await storage.updateUserPoints(
        userId, 
        validatedData.points,
        validatedData.weightKg
      );
      
      res.status(201).json(item);
    } catch (error) {
      console.error("Error creating recycling item:", error);
      res.status(400).json({ error: "Invalid recycling item data" });
    }
  });

  // Rewards routes
  app.get("/api/rewards", async (req, res) => {
    try {
      const rewardsList = await storage.getAllRewards();
      res.json(rewardsList);
    } catch (error) {
      console.error("Error fetching rewards:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Redemptions routes
  app.post("/api/redemptions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertRedemptionSchema.parse({
        ...req.body,
        userId,
      });
      
      // Check if user has enough points
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      if (user.totalPoints < validatedData.pointsSpent) {
        return res.status(400).json({ error: "Insufficient points" });
      }
      
      // Create redemption
      const redemption = await storage.createRedemption(validatedData);
      
      // Deduct points from user
      await storage.updateUserPoints(userId, -validatedData.pointsSpent);
      
      res.status(201).json(redemption);
    } catch (error) {
      console.error("Error creating redemption:", error);
      res.status(400).json({ error: "Invalid redemption data" });
    }
  });

  app.get("/api/redemptions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const redemptionsList = await storage.getUserRedemptions(userId);
      res.json(redemptionsList);
    } catch (error) {
      console.error("Error fetching redemptions:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  return httpServer;
}
