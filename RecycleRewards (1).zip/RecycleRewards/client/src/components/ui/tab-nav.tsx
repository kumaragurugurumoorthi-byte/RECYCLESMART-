import { Link, useLocation } from "wouter";
import { Home, History, ScanLine, Gift, User } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function TabNav() {
  const [location] = useLocation();

  const tabs = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/history", icon: History, label: "History" },
    { href: "/scanner", icon: ScanLine, label: "Scan", isPrimary: true },
    { href: "/points", icon: Gift, label: "Rewards" },
    { href: "/account", icon: User, label: "Account" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-lg border-t border-border pb-safe-area-bottom dark:bg-black/80">
      <div className="flex items-center justify-around p-2 max-w-md mx-auto h-16">
        {tabs.map((tab) => {
          const isActive = location === tab.href;
          
          return (
            <Link key={tab.href} href={tab.href}>
              <div className={cn(
                "relative flex flex-col items-center justify-center w-16 h-full cursor-pointer transition-colors",
                isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
              )}>
                {isActive && (
                  <motion.div
                    className="absolute -top-2 w-8 h-1 bg-primary rounded-full"
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}
                
                {tab.isPrimary ? (
                  <div className="absolute -top-8 bg-primary text-primary-foreground p-4 rounded-full shadow-lg shadow-primary/30 border-4 border-background transform transition-transform active:scale-95">
                    <tab.icon size={24} />
                  </div>
                ) : (
                  <tab.icon size={24} strokeWidth={isActive ? 2.5 : 2} />
                )}
                
                <span className={cn("text-[10px] mt-1 font-medium", tab.isPrimary && "mt-8")}>
                  {tab.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
