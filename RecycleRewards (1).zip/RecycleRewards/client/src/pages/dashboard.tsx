import { motion } from "framer-motion";
import { ArrowUpRight, Leaf, Recycle, TrendingUp, Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { getRecyclingHistory } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";
import heroImage from "@assets/generated_images/clean_eco-friendly_3d_recycling_illustration.png";
import { format } from "date-fns";
import { Link } from "wouter";

export default function Dashboard() {
  const { user, isLoading: userLoading } = useAuth();

  const { data: history = [], isLoading: historyLoading } = useQuery({
    queryKey: ["recycling-history"],
    queryFn: getRecyclingHistory,
    enabled: !!user,
  });

  const stats = [
    { label: "Total Recycled", value: `${user?.totalRecycled || 0} kg`, icon: Recycle, color: "text-emerald-500" },
    { label: "Carbon Saved", value: `${user?.carbonSaved || 0} kg`, icon: Leaf, color: "text-green-500" },
    { label: "Points Earned", value: user?.totalPoints?.toLocaleString() || "0", icon: TrendingUp, color: "text-teal-500" },
  ];

  const weeklyGoal = user ? Math.min((user.totalRecycled / 150) * 100, 100) : 0;
  const displayName = user?.firstName || user?.email?.split('@')[0] || "User";

  if (userLoading) {
    return (
      <div className="pb-24 pt-6 px-4 max-w-md mx-auto space-y-6">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-48 w-full rounded-3xl" />
        <div className="grid grid-cols-3 gap-3">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 pt-6 px-4 max-w-md mx-auto space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-foreground" data-testid="text-greeting">
            Vanakkam, {displayName}! 🙏
          </h1>
          <p className="text-muted-foreground">Let's make Singara Chennai clean!</p>
        </div>
        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20 overflow-hidden">
          {user?.profileImageUrl ? (
            <img src={user.profileImageUrl} alt="" className="h-full w-full object-cover" />
          ) : (
            <span className="font-heading font-bold text-primary">{displayName.charAt(0).toUpperCase()}</span>
          )}
        </div>
      </div>

      {/* Hero Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary to-teal-600 text-white shadow-xl shadow-primary/20"
      >
        <div className="absolute inset-0 opacity-20 mix-blend-overlay pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
        <div className="p-6 relative z-10">
          <div className="flex justify-between items-start">
            <div>
              <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-medium mb-3 border border-white/10">
                Marina Beach Cleanup
              </span>
              <h2 className="text-3xl font-bold mb-1" data-testid="text-goal-percentage">{Math.floor(weeklyGoal)}%</h2>
              <p className="text-primary-foreground/80 text-sm mb-4">of your monthly goal</p>
            </div>
            <img src={heroImage} alt="Recycling 3D" className="w-24 h-24 object-cover rounded-2xl border-2 border-white/20 shadow-lg rotate-3" />
          </div>
          
          <Progress value={weeklyGoal} className="h-3 bg-black/20" />
          <div className="mt-4 flex gap-2">
            <Button size="sm" variant="secondary" className="w-full bg-white text-primary hover:bg-white/90 border-0 font-semibold shadow-none" data-testid="button-view-details">
              View Details
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-3">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="border-none shadow-sm bg-white/50 backdrop-blur-sm">
              <CardContent className="p-4 flex flex-col items-center text-center gap-2">
                <div className={`p-2 rounded-full bg-background ${stat.color} bg-opacity-10`}>
                  <stat.icon size={20} className={stat.color} />
                </div>
                <div>
                  <div className="text-lg font-bold" data-testid={`text-stat-${stat.label.toLowerCase().replace(' ', '-')}`}>{stat.value}</div>
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">{stat.label}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Daily Tip */}
      <div className="bg-secondary/50 rounded-2xl p-5 border border-secondary flex gap-4 items-start">
        <div className="bg-background p-2 rounded-xl shadow-sm text-primary shrink-0">
          <Info size={24} />
        </div>
        <div>
          <h3 className="font-semibold mb-1 text-foreground">Chennai Fact</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Chennai generates over 5,000 tons of waste daily. Segregating your Aavin packets helps the corporation immensely! 🗑️
          </p>
        </div>
      </div>

      {/* Recent Activity Preview */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-lg">Recent Activity</h3>
          <Link href="/history">
            <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80 p-0 h-auto font-medium" data-testid="link-see-all">
              See all <ArrowUpRight size={16} className="ml-1" />
            </Button>
          </Link>
        </div>
        <div className="space-y-3">
          {historyLoading ? (
            <>
              <Skeleton className="h-20 rounded-2xl" />
              <Skeleton className="h-20 rounded-2xl" />
            </>
          ) : history.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <p>No recycling activity yet!</p>
              <Link href="/scanner">
                <Button variant="link" className="text-primary mt-2">Scan your first item</Button>
              </Link>
            </div>
          ) : (
            history.slice(0, 2).map((item) => (
              <div key={item.id} className="flex items-center justify-between p-4 bg-card rounded-2xl shadow-sm border border-border/50" data-testid={`card-activity-${item.id}`}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center">
                    <Recycle size={20} />
                  </div>
                  <div>
                    <p className="font-semibold" data-testid={`text-item-type-${item.id}`}>{item.itemType}</p>
                    <p className="text-xs text-muted-foreground">
                      {format(new Date(item.scannedAt), "MMM d, h:mm a")}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-bold text-primary" data-testid={`text-points-${item.id}`}>+{item.points} pts</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
