import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getRewards, createRedemption } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

export default function Points() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, isLoading: userLoading } = useAuth();

  const { data: rewards = [], isLoading: rewardsLoading } = useQuery({
    queryKey: ["rewards"],
    queryFn: getRewards,
  });

  const redeemMutation = useMutation({
    mutationFn: (rewardId: number) => {
      const reward = rewards.find(r => r.id === rewardId);
      if (!reward) throw new Error("Reward not found");
      
      return createRedemption({
        rewardId,
        pointsSpent: reward.cost,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Redeemed Successfully!",
        description: "Your reward will be sent to your email.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Redemption Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const tierProgress = user ? Math.min((user.totalPoints / 3000) * 100, 100) : 0;
  const pointsToGold = user ? Math.max(3000 - user.totalPoints, 0) : 0;

  if (userLoading || rewardsLoading) {
    return (
      <div className="pb-24 pt-6 px-4 max-w-md mx-auto">
        <Skeleton className="h-16 w-48 mx-auto mb-8" />
        <Skeleton className="h-32 w-full rounded-3xl mb-8" />
        <div className="space-y-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="pb-24 pt-6 px-4 max-w-md mx-auto">
      <div className="mb-8 text-center">
        <h1 className="text-2xl font-bold text-foreground mb-2" data-testid="text-page-title">Namma Rewards</h1>
        <div className="inline-flex items-center justify-center px-4 py-2 bg-primary/10 text-primary rounded-full font-bold text-xl border border-primary/20" data-testid="text-total-points">
          <Star className="w-5 h-5 mr-2 fill-primary" /> {user?.totalPoints?.toLocaleString() || 0} PTS
        </div>
      </div>

      <div className="mb-8 p-5 bg-card rounded-3xl shadow-lg border border-border relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-accent/30 rounded-full blur-3xl -mr-10 -mt-10"></div>
        <div className="relative z-10">
          <div className="flex justify-between mb-2">
            <h3 className="font-bold">{user?.tier || "Silver"} Tier</h3>
            <span className="text-xs font-medium text-muted-foreground" data-testid="text-points-to-gold">{pointsToGold} pts to Gold</span>
          </div>
          <Progress value={tierProgress} className="h-2.5 mb-4 bg-secondary" />
          <p className="text-sm text-muted-foreground">Unlock 1.5x points multiplier at Gold tier!</p>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="w-full mb-6 bg-transparent h-auto p-0 gap-2 overflow-x-auto justify-start no-scrollbar">
          <TabsTrigger value="all" className="rounded-full px-5 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground border border-border bg-white" data-testid="tab-all">All</TabsTrigger>
          <TabsTrigger value="coupons" className="rounded-full px-5 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground border border-border bg-white" data-testid="tab-coupons">Coupons</TabsTrigger>
          <TabsTrigger value="donations" className="rounded-full px-5 py-2.5 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground border border-border bg-white" data-testid="tab-donations">Donations</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <h3 className="font-bold text-lg mb-4">Chennai Specials</h3>
          {rewards.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No rewards available yet. Check back soon!
            </div>
          ) : (
            rewards.map((reward, i) => (
              <motion.div
                key={reward.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="group relative bg-white rounded-2xl p-4 shadow-sm border border-border/50 hover:shadow-md transition-shadow"
                data-testid={`card-reward-${reward.id}`}
              >
                <div className="flex gap-4">
                  <div className={`w-16 h-16 rounded-xl ${reward.color} flex items-center justify-center text-3xl shadow-lg`}>
                    {reward.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide mb-1">{reward.company}</p>
                        <h3 className="font-bold text-lg leading-none mb-2" data-testid={`text-reward-title-${reward.id}`}>{reward.title}</h3>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-bold text-primary" data-testid={`text-reward-cost-${reward.id}`}>{reward.cost} pts</span>
                      <Button 
                        size="sm" 
                        className="rounded-full px-4 h-8"
                        onClick={() => redeemMutation.mutate(reward.id)}
                        disabled={!user || (user.totalPoints || 0) < reward.cost || redeemMutation.isPending}
                        data-testid={`button-redeem-${reward.id}`}
                      >
                        {redeemMutation.isPending ? "Redeeming..." : "Redeem"}
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="coupons" className="space-y-4">
          <h3 className="font-bold text-lg mb-4">Coupons</h3>
          {rewards.filter(r => r.category === 'coupon').length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No coupons available</div>
          ) : (
            rewards.filter(r => r.category === 'coupon').map((reward, i) => (
              <motion.div
                key={reward.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="group relative bg-white rounded-2xl p-4 shadow-sm border border-border/50"
              >
                <div className="flex gap-4">
                  <div className={`w-16 h-16 rounded-xl ${reward.color} flex items-center justify-center text-3xl shadow-lg`}>
                    {reward.icon}
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground font-medium uppercase">{reward.company}</p>
                    <h3 className="font-bold text-lg">{reward.title}</h3>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-bold text-primary">{reward.cost} pts</span>
                      <Button 
                        size="sm" 
                        className="rounded-full px-4 h-8"
                        onClick={() => redeemMutation.mutate(reward.id)}
                        disabled={!user || (user.totalPoints || 0) < reward.cost}
                      >
                        Redeem
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="donations" className="space-y-4">
          <h3 className="font-bold text-lg mb-4">Environmental Causes</h3>
          {rewards.filter(r => r.category === 'donation').length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No donations available</div>
          ) : (
            rewards.filter(r => r.category === 'donation').map((reward, i) => (
              <motion.div
                key={reward.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="group relative bg-white rounded-2xl p-4 shadow-sm border border-border/50"
              >
                <div className="flex gap-4">
                  <div className={`w-16 h-16 rounded-xl ${reward.color} flex items-center justify-center text-3xl shadow-lg`}>
                    {reward.icon}
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-muted-foreground font-medium uppercase">{reward.company}</p>
                    <h3 className="font-bold text-lg">{reward.title}</h3>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-bold text-primary">{reward.cost} pts</span>
                      <Button 
                        size="sm" 
                        className="rounded-full px-4 h-8"
                        onClick={() => redeemMutation.mutate(reward.id)}
                        disabled={!user || (user.totalPoints || 0) < reward.cost}
                      >
                        Donate
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
