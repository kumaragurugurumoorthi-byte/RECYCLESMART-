import { User, Settings, Bell, Shield, LogOut, ChevronRight, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";

export default function Account() {
  const { user, isLoading } = useAuth();

  const displayName = user?.firstName && user?.lastName 
    ? `${user.firstName} ${user.lastName}`
    : user?.firstName || user?.email?.split('@')[0] || "User";

  const initials = user?.firstName && user?.lastName 
    ? `${user.firstName[0]}${user.lastName[0]}`
    : displayName.charAt(0).toUpperCase();

  if (isLoading) {
    return (
      <div className="pb-24 pt-6 px-4 max-w-md mx-auto">
        <div className="flex flex-col items-center mb-8">
          <Skeleton className="h-24 w-24 rounded-full mb-4" />
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-32" />
        </div>
        <Skeleton className="h-32 w-full mb-6" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  return (
    <div className="pb-24 pt-6 px-4 max-w-md mx-auto">
      <div className="flex flex-col items-center mb-8">
        <div className="relative mb-4">
          <Avatar className="h-24 w-24 border-4 border-white shadow-xl">
            <AvatarImage src={user?.profileImageUrl || undefined} className="object-cover" />
            <AvatarFallback data-testid="text-avatar-fallback">{initials}</AvatarFallback>
          </Avatar>
          <div className="absolute bottom-0 right-0 bg-primary text-white p-1.5 rounded-full border-4 border-background">
            <User size={16} />
          </div>
        </div>
        <h1 className="text-2xl font-bold" data-testid="text-user-name">{displayName}</h1>
        <p className="text-muted-foreground" data-testid="text-user-tier">Chennai Eco-Warrior • {user?.tier || "Silver"} Tier</p>
        <p className="text-primary font-bold mt-1">{user?.totalPoints?.toLocaleString() || 0} Points</p>
      </div>

      <div className="space-y-6">
        <section>
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3 pl-1">Settings</h3>
          <div className="bg-card rounded-2xl border border-border/50 overflow-hidden">
            <div className="p-4 flex items-center justify-between hover:bg-secondary/50 transition-colors cursor-pointer">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                  <Bell size={20} />
                </div>
                <span className="font-medium">Notifications</span>
              </div>
              <Switch defaultChecked data-testid="switch-notifications" />
            </div>
            <Separator />
            <div className="p-4 flex items-center justify-between hover:bg-secondary/50 transition-colors cursor-pointer" data-testid="button-language">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-50 text-orange-600 rounded-lg">
                  <Languages size={20} />
                </div>
                <span className="font-medium">Language</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                {user?.language || "Tamil"} <ChevronRight size={16} />
              </div>
            </div>
            <Separator />
            <div className="p-4 flex items-center justify-between hover:bg-secondary/50 transition-colors cursor-pointer" data-testid="button-location">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-50 text-red-600 rounded-lg">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                </div>
                <span className="font-medium">Location</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                {user?.location || "Chennai"} <ChevronRight size={16} />
              </div>
            </div>
          </div>
        </section>

        <section>
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3 pl-1">General</h3>
          <div className="bg-card rounded-2xl border border-border/50 overflow-hidden">
            <div className="p-4 flex items-center justify-between hover:bg-secondary/50 transition-colors cursor-pointer" data-testid="button-edit-profile">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gray-100 text-gray-600 rounded-lg">
                  <User size={20} />
                </div>
                <span className="font-medium">Edit Profile</span>
              </div>
              <ChevronRight size={20} className="text-muted-foreground" />
            </div>
            <Separator />
            <div className="p-4 flex items-center justify-between hover:bg-secondary/50 transition-colors cursor-pointer" data-testid="button-privacy">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                  <Shield size={20} />
                </div>
                <span className="font-medium">Privacy & Security</span>
              </div>
              <ChevronRight size={20} className="text-muted-foreground" />
            </div>
          </div>
        </section>

        <a href="/api/logout">
          <Button variant="destructive" className="w-full h-12 rounded-xl font-semibold shadow-sm" data-testid="button-logout">
            <LogOut className="mr-2 h-4 w-4" /> Log Out
          </Button>
        </a>

        <p className="text-center text-xs text-muted-foreground pt-4">
          Version 1.0.2 • Namma EcoCycle Chennai
        </p>
      </div>
    </div>
  );
}
