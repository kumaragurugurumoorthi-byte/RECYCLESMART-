import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Zap, Image as ImageIcon, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createRecyclingItem } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";

const RECYCLABLE_ITEMS = [
  { type: "Aavin Milk Packet (Blue)", points: 25, weight: 0.5 },
  { type: "Bisleri Bottle (1L)", points: 50, weight: 1 },
  { type: "The Hindu Newspaper", points: 120, weight: 3 },
  { type: "Idli Batter Cover", points: 15, weight: 0.3 },
  { type: "Bovonto Can", points: 10, weight: 0.2 },
];

export default function Scanner() {
  const [isScanning, setIsScanning] = useState(true);
  const [scannedData, setScannedData] = useState<null | { type: string, points: number, weight: number }>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const createItemMutation = useMutation({
    mutationFn: createRecyclingItem,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["recycling-history"] });
      toast({
        title: "Nannari! Points Added!",
        description: `You've earned ${scannedData?.points} points.`,
      });
      resetScan();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to record item. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleScan = () => {
    setIsScanning(false);
    setTimeout(() => {
      const randomItem = RECYCLABLE_ITEMS[Math.floor(Math.random() * RECYCLABLE_ITEMS.length)];
      setScannedData({ 
        type: randomItem.type, 
        points: randomItem.points,
        weight: randomItem.weight
      });
    }, 500);
  };

  const resetScan = () => {
    setScannedData(null);
    setIsScanning(true);
  };

  const confirmScan = () => {
    if (!scannedData) return;
    
    createItemMutation.mutate({
      itemType: scannedData.type,
      amount: "1 item",
      points: scannedData.points,
      weightKg: scannedData.weight,
    });
  };

  return (
    <div className="h-screen flex flex-col bg-black relative overflow-hidden">
      {/* Camera Viewfinder Mockup */}
      <div className="absolute inset-0 z-0">
        <div className="w-full h-full bg-gray-900 relative">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1605600659908-0ef719419d41?q=80&w=2536&auto=format&fit=crop')] bg-cover bg-center opacity-50"></div>
          
          {isScanning && (
            <>
              <motion.div 
                initial={{ top: "20%" }}
                animate={{ top: "60%" }}
                transition={{ duration: 2, repeat: Infinity, repeatType: "reverse", ease: "linear" }}
                className="absolute left-8 right-8 h-0.5 bg-primary shadow-[0_0_20px_rgba(16,185,129,0.8)] z-20"
              />
              <div className="absolute inset-0 bg-black/30 z-10">
                <div className="absolute top-1/4 left-8 right-8 bottom-1/4 border-2 border-white/50 rounded-3xl">
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-primary -mt-1 -ml-1 rounded-tl-xl"></div>
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-primary -mt-1 -mr-1 rounded-tr-xl"></div>
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-primary -mb-1 -ml-1 rounded-bl-xl"></div>
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-primary -mb-1 -mr-1 rounded-br-xl"></div>
                </div>
                <p className="absolute top-[20%] left-0 right-0 text-center text-white/80 font-medium">
                  Align Aavin packet or bottle
                </p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Top Controls */}
      <div className="absolute top-0 left-0 right-0 p-6 z-30 flex justify-between items-start pt-12">
        <Link href="/">
          <Button variant="secondary" size="icon" className="rounded-full bg-black/40 text-white hover:bg-black/60 border-none backdrop-blur-md" data-testid="button-close">
            <X size={24} />
          </Button>
        </Link>
        <div className="flex gap-4">
          <Button variant="secondary" size="icon" className="rounded-full bg-black/40 text-white hover:bg-black/60 border-none backdrop-blur-md" data-testid="button-flash">
            <Zap size={20} />
          </Button>
        </div>
      </div>

      {/* Bottom Controls / Result */}
      <div className="absolute bottom-0 left-0 right-0 z-30 p-6 pb-28 bg-gradient-to-t from-black/90 to-transparent">
        <AnimatePresence mode="wait">
          {!scannedData ? (
            <motion.div 
              key="controls"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="flex justify-between items-center"
            >
              <Button variant="ghost" size="icon" className="text-white/80 hover:text-white hover:bg-white/10 h-14 w-14" data-testid="button-gallery">
                <ImageIcon size={28} />
              </Button>
              
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={handleScan}
                className="h-20 w-20 rounded-full border-4 border-white flex items-center justify-center bg-transparent relative"
                data-testid="button-scan"
              >
                <div className="h-16 w-16 rounded-full bg-white" />
              </motion.button>
              
              <div className="w-14" />
            </motion.div>
          ) : (
            <motion.div 
              key="result"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-3xl p-6 text-black shadow-2xl"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="h-16 w-16 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                  <CheckCircle2 size={32} />
                </div>
                <div>
                  <h3 className="text-lg font-bold" data-testid="text-scanned-item">{scannedData.type}</h3>
                  <p className="text-muted-foreground">Recyclable Material</p>
                </div>
                <div className="ml-auto text-right">
                  <span className="block text-2xl font-bold text-primary" data-testid="text-scanned-points">+{scannedData.points}</span>
                  <span className="text-xs font-medium text-muted-foreground">PTS</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <Button 
                  variant="outline" 
                  onClick={resetScan} 
                  className="h-12 rounded-xl"
                  disabled={createItemMutation.isPending}
                  data-testid="button-scan-another"
                >
                  Scan Another
                </Button>
                <Button 
                  onClick={confirmScan} 
                  className="h-12 rounded-xl font-bold"
                  disabled={createItemMutation.isPending}
                  data-testid="button-add-wallet"
                >
                  {createItemMutation.isPending ? "Adding..." : "Add to Wallet"}
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
