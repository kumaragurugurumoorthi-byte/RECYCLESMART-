import { motion } from "framer-motion";
import { Recycle, Search, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQuery } from "@tanstack/react-query";
import { getRecyclingHistory } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { useState } from "react";

export default function History() {
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth();
  
  const { data: historyItems = [], isLoading } = useQuery({
    queryKey: ["recycling-history"],
    queryFn: getRecyclingHistory,
    enabled: !!user,
  });

  const filteredItems = historyItems.filter(item => 
    item.itemType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getItemEmoji = (itemType: string) => {
    if (itemType.includes('Packet') || itemType.includes('Cover') || itemType.includes('Bottle')) return '🧴';
    if (itemType.includes('Paper') || itemType.includes('Cardboard') || itemType.includes('Hindu')) return '📄';
    if (itemType.includes('Glass')) return '🏺';
    if (itemType.includes('Can')) return '🥫';
    if (itemType.includes('Mobile')) return '📱';
    return '♻️';
  };

  const getItemColor = (itemType: string) => {
    if (itemType.includes('Packet') || itemType.includes('Cover') || itemType.includes('Bottle')) return 'bg-blue-50 text-blue-500';
    if (itemType.includes('Paper') || itemType.includes('Cardboard') || itemType.includes('Hindu')) return 'bg-amber-50 text-amber-600';
    if (itemType.includes('Glass')) return 'bg-teal-50 text-teal-600';
    if (itemType.includes('Can')) return 'bg-gray-100 text-gray-600';
    if (itemType.includes('Mobile')) return 'bg-purple-50 text-purple-600';
    return 'bg-green-50 text-green-600';
  };

  return (
    <div className="pb-24 pt-6 px-4 max-w-md mx-auto h-screen flex flex-col">
      <div className="space-y-4 mb-6">
        <h1 className="text-2xl font-bold text-foreground" data-testid="text-page-title">Recycling History</h1>
        
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
            <Input 
              placeholder="Search items..." 
              className="pl-10 bg-secondary/50 border-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
          </div>
          <Button variant="outline" size="icon" className="shrink-0 border-none bg-secondary/50" data-testid="button-filter">
            <Filter size={18} />
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1 -mx-4 px-4">
        <div className="space-y-4">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-2xl" />
            ))
          ) : filteredItems.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              {searchQuery ? 'No items found matching your search' : 'No recycling history yet. Start scanning!'}
            </div>
          ) : (
            filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between p-4 bg-card rounded-2xl shadow-sm border border-border/50"
                data-testid={`card-history-${item.id}`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl ${getItemColor(item.itemType)}`}>
                    {getItemEmoji(item.itemType)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground" data-testid={`text-item-type-${item.id}`}>{item.itemType}</h3>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      {item.amount} • {format(new Date(item.scannedAt), "MMM d, h:mm a")}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="block font-bold text-primary text-lg" data-testid={`text-points-${item.id}`}>+{item.points}</span>
                  <span className="text-xs text-muted-foreground font-medium">points</span>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
