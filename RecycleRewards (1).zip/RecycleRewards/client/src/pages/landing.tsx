import { motion } from "framer-motion";
import { Recycle, Leaf, Gift, ArrowRight, ScanLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImage from "@assets/generated_images/clean_eco-friendly_3d_recycling_illustration.png";

export default function Landing() {
  const features = [
    { icon: ScanLine, title: "Scan & Earn", description: "Scan recyclables to earn points instantly" },
    { icon: Recycle, title: "Track Progress", description: "Monitor your environmental impact" },
    { icon: Gift, title: "Redeem Rewards", description: "Use points at local Chennai stores" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/30">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 mix-blend-overlay pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
        
        <div className="max-w-md mx-auto px-6 pt-16 pb-12">
          {/* Logo */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 mb-12"
          >
            <div className="h-10 w-10 bg-primary rounded-xl flex items-center justify-center">
              <Recycle className="h-6 w-6 text-white" />
            </div>
            <span className="font-heading font-bold text-xl">EcoCycle</span>
          </motion.div>

          {/* Hero Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold font-heading mb-4 leading-tight">
              Recycle for <span className="text-primary">Chennai</span>, Earn Rewards
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Join the Singara Chennai movement. Scan your recyclables, earn points, and redeem at your favorite local stores.
            </p>
          </motion.div>

          {/* Hero Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="relative mb-12"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-teal-500/20 rounded-3xl blur-3xl"></div>
            <img 
              src={heroImage} 
              alt="Recycling illustration" 
              className="relative w-full h-64 object-cover rounded-3xl border border-primary/20 shadow-xl"
            />
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-4 mb-12"
          >
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 + i * 0.1 }}
                className="flex items-center gap-4 p-4 bg-card/50 backdrop-blur-sm rounded-2xl border border-border/50"
              >
                <div className="h-12 w-12 bg-primary/10 rounded-xl flex items-center justify-center shrink-0">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
          >
            <a href="/api/login">
              <Button 
                size="lg" 
                className="w-full h-14 text-lg font-semibold rounded-2xl shadow-lg shadow-primary/30"
                data-testid="button-login"
              >
                Get Started <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
            <p className="text-center text-sm text-muted-foreground mt-4">
              Sign in with Google, GitHub, or Email
            </p>
          </motion.div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center py-8 text-sm text-muted-foreground">
        <p>Made with 💚 for Namma Chennai</p>
      </div>
    </div>
  );
}
