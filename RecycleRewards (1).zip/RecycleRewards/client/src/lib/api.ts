import type { User, RecyclingItem, Reward, InsertRecyclingItem, InsertRedemption } from "@shared/schema";

const API_BASE = "/api";

export async function getRecyclingHistory(): Promise<RecyclingItem[]> {
  const res = await fetch(`${API_BASE}/recycling-history`, { credentials: "include" });
  if (!res.ok) throw new Error("Failed to fetch recycling history");
  return res.json();
}

export async function createRecyclingItem(item: Omit<InsertRecyclingItem, "userId">): Promise<RecyclingItem> {
  const res = await fetch(`${API_BASE}/recycling-items`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(item),
    credentials: "include",
  });
  if (!res.ok) throw new Error("Failed to create recycling item");
  return res.json();
}

export async function getRewards(): Promise<Reward[]> {
  const res = await fetch(`${API_BASE}/rewards`);
  if (!res.ok) throw new Error("Failed to fetch rewards");
  return res.json();
}

export async function createRedemption(redemption: Omit<InsertRedemption, "userId">): Promise<void> {
  const res = await fetch(`${API_BASE}/redemptions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(redemption),
    credentials: "include",
  });
  if (!res.ok) {
    const error = await res.json();
    throw new Error(error.error || "Failed to redeem reward");
  }
}
