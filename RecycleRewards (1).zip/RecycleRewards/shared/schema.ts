import { sql } from "drizzle-orm";
import { pgTable, text, varchar, serial, integer, timestamp, boolean, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth (using varchar id to match Replit's user IDs)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  name: text("name"),
  profileImageUrl: varchar("profile_image_url"),
  avatarUrl: text("avatar_url"),
  location: text("location").default("Adyar, Chennai"),
  language: text("language").default("Tamil"),
  totalPoints: integer("total_points").notNull().default(0),
  totalRecycled: integer("total_recycled_kg").notNull().default(0),
  carbonSaved: integer("carbon_saved_kg").notNull().default(0),
  tier: text("tier").notNull().default("Silver"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const recyclingItems = pgTable("recycling_items", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  itemType: text("item_type").notNull(),
  amount: text("amount").notNull(),
  points: integer("points").notNull(),
  weightKg: integer("weight_kg").notNull().default(0),
  scannedAt: timestamp("scanned_at").defaultNow().notNull(),
});

export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  cost: integer("cost").notNull(),
  icon: text("icon").notNull(),
  color: text("color").notNull(),
  category: text("category").notNull().default("coupon"),
  isActive: boolean("is_active").notNull().default(true),
});

export const redemptions = pgTable("redemptions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  rewardId: integer("reward_id").notNull().references(() => rewards.id),
  pointsSpent: integer("points_spent").notNull(),
  redeemedAt: timestamp("redeemed_at").defaultNow().notNull(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const insertRecyclingItemSchema = createInsertSchema(recyclingItems).omit({
  id: true,
  scannedAt: true,
});

export const insertRewardSchema = createInsertSchema(rewards).omit({
  id: true,
});

export const insertRedemptionSchema = createInsertSchema(redemptions).omit({
  id: true,
  redeemedAt: true,
});

export type RecyclingItem = typeof recyclingItems.$inferSelect;
export type InsertRecyclingItem = z.infer<typeof insertRecyclingItemSchema>;

export type Reward = typeof rewards.$inferSelect;
export type InsertReward = z.infer<typeof insertRewardSchema>;

export type Redemption = typeof redemptions.$inferSelect;
export type InsertRedemption = z.infer<typeof insertRedemptionSchema>;
